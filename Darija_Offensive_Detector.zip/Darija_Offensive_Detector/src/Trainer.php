<?php

namespace DarijaOffensiveDetector;

/**
 * Trains model.json from a labelled CSV (columns: text,label; 1 = offensive, 0 = not).
 * Holds back 20% to measure accuracy, picks a threshold that keeps precision at the target,
 * then retrains on everything and saves.
 */
class Trainer
{
    public function __construct(private Engine $filter)
    {
    }

    /**
     * @param  callable(string): void  $log
     * @return array{rows: int, threshold: float, features: int, bytes: int}
     */
    public function train(string $csv, string $out, array $options = [], ?callable $log = null): array
    {
        $log ??= fn (string $line) => print($line . PHP_EOL);
        $epochs = (int) ($options['epochs'] ?? 3);
        $l2 = (float) ($options['l2'] ?? 0.001);
        $rate = (float) ($options['rate'] ?? 0.3);
        $target = (float) ($options['precision'] ?? 0.95);
        $maxFeatures = (int) ($options['max_features'] ?? 60000);

        $rows = $this->readCsv($csv);
        $log(count($rows) . ' labelled rows read.');

        $data = [];
        foreach ($rows as [$text, $label]) {
            $data[] = [array_keys(Model::features($this->filter, $text)), $label];
        }

        mt_srand(42);
        shuffle($data);
        $cut = (int) floor(count($data) * 0.8);
        [$weights, $bias] = $this->fit(array_slice($data, 0, $cut), $epochs, $l2, $rate);
        $scored = array_map(fn ($row) => [$this->predict($weights, $bias, $row[0]), $row[1]], array_slice($data, $cut));
        $threshold = $this->pickThreshold($scored, $target);
        $log($this->report($scored, 0.5, 'held-out 20% at 0.50'));
        $log($this->report($scored, $threshold, 'held-out 20% at threshold ' . number_format($threshold, 2)));

        [$weights, $bias] = $this->fit($data, $epochs, $l2, $rate);
        $abs = array_map('abs', $weights);
        arsort($abs);
        $weights = array_map(fn ($w) => round($w, 4), array_intersect_key($weights, array_slice($abs, 0, $maxFeatures, true)));

        @mkdir(dirname($out), 0755, true);
        file_put_contents($out, json_encode([
            'trained_at' => date('c'),
            'rows' => count($data),
            'threshold' => round($threshold, 3),
            'bias' => round($bias, 4),
            'weights' => $weights,
        ], JSON_UNESCAPED_UNICODE));

        return ['rows' => count($data), 'threshold' => $threshold, 'features' => count($weights), 'bytes' => (int) filesize($out)];
    }

    /** @return list<array{0: string, 1: int}> */
    private function readCsv(string $path): array
    {
        $handle = fopen($path, 'r');
        if ($handle === false) {
            throw new \RuntimeException("Cannot read $path");
        }
        $header = array_map(fn ($h) => strtolower(trim(preg_replace('/^\x{FEFF}/u', '', (string) $h))), fgetcsv($handle) ?: []);
        $textAt = array_search('text', $header, true);
        $labelAt = array_search('label', $header, true);
        $textAt = $textAt === false ? 0 : $textAt;
        $labelAt = $labelAt === false ? 1 : $labelAt;
        $rows = [];
        while (($row = fgetcsv($handle)) !== false) {
            if (isset($row[$textAt], $row[$labelAt]) && in_array(trim($row[$labelAt]), ['0', '1'], true)) {
                $rows[] = [(string) $row[$textAt], (int) trim($row[$labelAt])];
            }
        }
        fclose($handle);

        return $rows;
    }

    /** Logistic regression with AdaGrad and light L2. Features are present/absent. */
    private function fit(array $data, int $epochs, float $l2, float $rate): array
    {
        $w = $g = [];
        $bias = $gb = 0.0;
        for ($epoch = 0; $epoch < $epochs; $epoch++) {
            foreach ($data as [$features, $label]) {
                $err = $this->predict($w, $bias, $features) - $label;
                foreach ($features as $f) {
                    $grad = $err + $l2 * ($w[$f] ?? 0.0);
                    $g[$f] = ($g[$f] ?? 0.0) + $grad * $grad;
                    $w[$f] = ($w[$f] ?? 0.0) - $rate * $grad / (sqrt($g[$f]) + 1e-8);
                }
                $gb += $err * $err;
                $bias -= $rate * $err / (sqrt($gb) + 1e-8);
            }
        }

        return [$w, $bias];
    }

    private function predict(array $w, float $bias, array $features): float
    {
        $z = $bias;
        foreach ($features as $f) {
            $z += $w[$f] ?? 0.0;
        }

        return 1 / (1 + exp(-max(-30, min(30, $z))));
    }

    private function pickThreshold(array $scored, float $target): float
    {
        for ($t = 0.30; $t <= 0.99; $t += 0.01) {
            $tp = $fp = 0;
            foreach ($scored as [$p, $y]) {
                if ($p >= $t) {
                    $y ? $tp++ : $fp++;
                }
            }
            if ($tp + $fp > 0 && $tp / ($tp + $fp) >= $target) {
                return $t;
            }
        }

        return 0.99;
    }

    private function report(array $scored, float $t, string $label): string
    {
        $tp = $fp = $tn = $fn = 0;
        foreach ($scored as [$p, $y]) {
            $hit = $p >= $t;
            if ($hit && $y) $tp++; elseif ($hit) $fp++; elseif ($y) $fn++; else $tn++;
        }

        return sprintf('  %s: precision %.1f%%, recall %.1f%%, accuracy %.1f%%', $label,
            100 * $tp / max(1, $tp + $fp), 100 * $tp / max(1, $tp + $fn), 100 * ($tp + $tn) / max(1, count($scored)));
    }
}
