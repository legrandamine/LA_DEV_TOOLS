<?php

namespace DarijaOffensiveDetector;

/**
 * Detects offensive words in Moroccan Darija (Arabic script and Arabizi), Arabic, French and English.
 *
 *   Detector::detect('wld l9a7ba');        // true
 *   Detector::detect('salam khoya');       // false
 *
 *   $detector = new Detector(['extra_words' => ['my custom word']]);
 *   $detector->isOffensive($text);         // true / false
 *   $detector->findWords($text);           // ['qahba'] — what was found, for a warning message
 */
class Detector
{
    private static ?self $default = null;

    private Engine $engine;

    /**
     * Options, all optional:
     *  - extra_words   list of words or phrases to block on top of the built-in list
     *  - allow_words   list of built-in words to stop blocking (a place or family name, for example)
     *  - family_words  block "your wife / your mother…" on their own (default true; false for chat)
     *  - use_model     use the trained model for insults with no listed word (default true)
     *  - threshold     how sure the model must be, 0 to 1 (default 0.99; lower catches more, blocks more names)
     *  - words_file    path to your own copy of config/words.php
     *
     * @param  array{extra_words?: list<string>, allow_words?: list<string>, family_words?: bool, use_model?: bool, threshold?: float, words_file?: string}  $options
     */
    public function __construct(array $options = [])
    {
        $root = dirname(__DIR__);
        $config = require $options['words_file'] ?? $root . '/config/words.php';

        foreach ($options['extra_words'] ?? [] as $word) {
            $word = trim((string) $word);
            if ($word !== '') {
                $config[str_contains($word, ' ') ? 'phrases' : 'tokens'][] = $word;
            }
        }
        if (! ($options['family_words'] ?? true)) {
            $config['family_tokens'] = $config['family_phrases'] = [];
        }
        if ($allow = $options['allow_words'] ?? []) {
            $allow = array_map(fn ($w) => mb_strtolower(trim((string) $w), 'UTF-8'), $allow);
            foreach (['tokens', 'phrases', 'stems', 'family_tokens', 'family_phrases'] as $kind) {
                $config[$kind] = array_values(array_filter($config[$kind] ?? [], fn ($w) => ! in_array(mb_strtolower($w, 'UTF-8'), $allow, true)));
            }
        }

        $model = ($options['use_model'] ?? true) ? $root . '/model/model.json' : null;
        $this->engine = new Engine($config, $model, isset($options['threshold']) ? (float) $options['threshold'] : null);
    }

    /** One-line check with the default settings: true if the text has a bad word, false if not. */
    public static function detect(?string $text): bool
    {
        return (self::$default ??= new self())->isOffensive($text);
    }

    /** True if the text has a bad word, false if not. */
    public function isOffensive(?string $text): bool
    {
        return $this->findWords($text) !== [];
    }

    /**
     * The bad words found, as listed (or the words the model reacted to). Empty array = clean.
     *
     * @return list<string>
     */
    public function findWords(?string $text): array
    {
        return $this->engine->check(['text' => (string) $text])['text'] ?? [];
    }

    /**
     * Checks several fields at once and returns only the offensive ones with their words:
     * ['name' => ['zebi']]. Empty array = everything is clean.
     *
     * @param  array<string, string|null>  $fields
     * @return array<string, list<string>>
     */
    public function checkFields(array $fields): array
    {
        return $this->engine->check($fields);
    }

    public function engine(): Engine
    {
        return $this->engine;
    }
}
