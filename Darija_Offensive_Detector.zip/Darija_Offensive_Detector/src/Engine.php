<?php

namespace DarijaOffensiveDetector;

use Normalizer;

/**
 * Detects insults and obscene words in Arabic, Moroccan Darija (Arabic script and Arabizi), French,
 * English and a few other languages, including disguised spellings. Plain PHP 8.1+, no framework.
 *
 * Three layers, all local and free:
 *   1. word list: tokens, phrases and stems (config/words.php)
 *   2. combination rules: harmless words that insult together ("your wife" + sexual slang)
 *   3. a small trained model (model/model.json), only for very sure cases, and only on text that
 *      looks like Darija: it was trained on Darija comments and guesses wrong on plain English or French
 *
 * Most people want the Detector class instead; this is the machinery behind it.
 */
class Engine
{
    /** Common Darija words written in Latin letters, used to tell Arabizi from English or French. */
    private const DARIJA_MARKERS = [
        'dyal', 'dial', 'diyal', 'dyali', 'dialk', 'dyalk', 'wach', 'wash', 'bzaf', 'bezaf', 'khoya', 'khti', 'rah', 'nta', 'nti',
        'ntoma', 'wld', 'weld', 'bghit', 'bghina', 'ghir', 'hna', 'hada', 'hadi', 'kifach', 'kifash', 'alach', 'mok', 'mmok', 'bok',
        'zwin', 'mzyan', 'walo', 'daba', 'safi', 'wakha', 'kayn', 'kain', 'makayn', 'wlah', 'wallah', 'chno', 'chnou', 'mnin',
        'bach', 'lli', 'howa', 'hiya', 'homa', 'fhad', 'labas', 'khay', 'sahbi', 'drari', 'bnadm', 'warah', 'mazal', 'baraka',
    ];

    /** Leetspeak: digits and symbols standing for Latin letters. */
    public const LEET = ['0' => 'o', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's', '7' => 't', '8' => 'b', '@' => 'a', '$' => 's', '!' => 'i', '|' => 'i', '€' => 'e', '£' => 'l', '+' => 't'];

    /** Arabizi: digits standing for Arabic sounds. */
    public const ARABIZI = ['3' => 'a', '7' => 'h', '9' => 'q', '2' => 'a', '5' => 'kh', '8' => 'gh', '6' => 't', '4' => 'dh'];

    /** Letters from other alphabets that look like Latin ones. */
    private const LOOKALIKES = [
        'а' => 'a', 'в' => 'b', 'е' => 'e', 'ё' => 'e', 'к' => 'k', 'м' => 'm', 'н' => 'h', 'о' => 'o', 'р' => 'p', 'с' => 'c',
        'т' => 't', 'у' => 'y', 'х' => 'x', 'і' => 'i', 'ј' => 'j', 'ѕ' => 's', 'ԁ' => 'd', 'ӏ' => 'l',
        'α' => 'a', 'β' => 'b', 'ε' => 'e', 'ι' => 'i', 'κ' => 'k', 'ν' => 'v', 'ο' => 'o', 'ρ' => 'p', 'τ' => 't', 'υ' => 'u', 'χ' => 'x',
    ];

    private ?array $lists = null;
    private ?Model $model;

    /**
     * @param  array  $config  the array from config/words.php (tokens, phrases, stems, combos)
     * @param  string|null  $modelPath  model.json, or null to run without the model
     * @param  float|null  $threshold  model score needed to flag (null = the one chosen at training)
     */
    public function __construct(private array $config, ?string $modelPath = null, private ?float $threshold = null)
    {
        $this->model = $modelPath !== null && is_file($modelPath) ? new Model($this, $modelPath) : null;
    }

    /** The bundled word lists and model. */
    public static function withDefaults(?float $threshold = null): self
    {
        $root = dirname(__DIR__);

        return new self(require $root . '/config/words.php', $root . '/model/model.json', $threshold);
    }

    /**
     * True when the text is written in Arabic script, uses Arabizi digits inside words ("9a7ba", "l3sel"),
     * or contains common Darija words written in Latin letters ("dyal", "bzaf", "khoya").
     */
    public function looksLikeDarija(string $text): bool
    {
        if (preg_match('/\p{Arabic}/u', $text)) {
            return true;
        }
        foreach (preg_split('/[^\p{L}\p{N}]+/u', mb_strtolower($text, 'UTF-8'), -1, PREG_SPLIT_NO_EMPTY) as $word) {
            if (preg_match('/\p{L}/u', $word) && preg_match('/[235679]/', $word)) {
                return true;
            }
            if (in_array($word, self::DARIJA_MARKERS, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Which fields contain bad words, and which: ['fullname' => ['zebi'], ...]. Empty array = clean.
     *
     * @param  array<string, string|null>  $fields
     * @return array<string, list<string>>
     */
    public function check(array $fields): array
    {
        $flagged = [];
        foreach ($fields as $name => $text) {
            $text = trim((string) $text);
            if ($text === '') {
                continue;
            }
            $words = $this->matches($text);
            if ($words === [] && $this->model !== null && $this->looksLikeDarija($text)) {
                $result = $this->model->score($text);
                if ($result['score'] >= ($this->threshold ?? $this->model->threshold())) {
                    $words = $result['words'] ?: ['…'];
                }
            }
            if ($words !== []) {
                $flagged[$name] = $words;
            }
        }

        return $flagged;
    }

    /** True when the text is offensive by any layer. */
    public function isOffensive(string $text): bool
    {
        return $this->check(['text' => $text]) !== [];
    }

    public function model(): ?Model
    {
        return $this->model;
    }

    /**
     * Words from the word list and combination rules found in the text (layers 1 and 2 only).
     *
     * @return list<string>
     */
    public function matches(string $text): array
    {
        $lists = $this->lists();
        $found = [];

        foreach ([null, self::LEET, self::ARABIZI] as $digits) {
            [$words, $spaced, $compact] = $this->shape($text, $digits);

            foreach ($words as $word) {
                foreach ($this->arabicVariants($word) as $variant) {
                    if (isset($lists['tokens'][$variant])) {
                        $found[] = $lists['tokens'][$variant];
                    }
                }
            }
            foreach ($lists['phrases'] as $phrase => $original) {
                if (str_contains($spaced, ' ' . $phrase . ' ')) {
                    $found[] = $original;
                }
            }
            foreach ($lists['stems'] as $stem => $original) {
                if (str_contains($compact, $stem)) {
                    $found[] = $original;
                }
            }
            foreach ($lists['combos'] as $combo) {
                if ($hit = $this->comboHit($combo, $words)) {
                    $found[] = $hit;
                }
            }
        }

        return array_values(array_unique($found));
    }

    /**
     * Cleans the text and returns [words, " words joined by spaces ", wordsjoinedtogether].
     *
     * @param  array<string, string>|null  $digits  how to read digits/symbols, or null to keep them
     */
    public function shape(string $text, ?array $digits = null): array
    {
        $text = $this->normalize($text);
        if ($digits !== null) {
            $text = strtr($text, $digits);
        }
        // "f*ck", "z.e.b.i", "zé-bi": masking characters between letters are dropped.
        $text = preg_replace('/(?<=[\p{L}\p{N}])[*_\-.\'’`~^]+(?=[\p{L}\p{N}])/u', '', $text);
        // Doubled letters: "zebbi" == "zebi", "قححبة" == "قحبة".
        $text = preg_replace('/(.)\1+/u', '$1', $text);

        $words = preg_split('/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);

        // "z e b i", "ق ح ب ة", letters split by emoji: join runs of single letters into one word.
        $joined = [];
        $run = '';
        foreach ($words as $word) {
            if (mb_strlen($word) === 1) {
                $run .= $word;
                continue;
            }
            if ($run !== '') {
                $joined[] = $run;
            }
            $run = '';
            $joined[] = $word;
        }
        if ($run !== '') {
            $joined[] = $run;
        }

        return [$joined, ' ' . implode(' ', $joined) . ' ', implode('', $joined)];
    }

    /**
     * Lower case, full-width and look-alike letters to plain Latin, unified Arabic letter forms,
     * no diacritics, tatweel, accents or invisible characters.
     */
    public function normalize(string $text): string
    {
        if (class_exists(Normalizer::class)) {
            $text = Normalizer::normalize($text, Normalizer::FORM_KC) ?: $text;
        }
        $text = mb_strtolower($text, 'UTF-8');
        $text = preg_replace('/[\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{2064}\x{FEFF}\x{00AD}]/u', '', $text);
        $text = strtr($text, self::LOOKALIKES);
        $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $text);
        $text = strtr($text, ['أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ٱ' => 'ا', 'ى' => 'ي', 'ئ' => 'ي', 'ؤ' => 'و', 'ة' => 'ه', 'گ' => 'ك', 'ڭ' => 'ك', 'ڤ' => 'ف', 'پ' => 'ب', 'ک' => 'ك', 'ی' => 'ي']);
        if (class_exists(Normalizer::class)) {
            $decomposed = Normalizer::normalize($text, Normalizer::FORM_D);
            if ($decomposed !== false) {
                $text = preg_replace('/\p{Mn}+/u', '', $decomposed);
            }
        }

        return trim((string) $text);
    }

    /** The configured lists, cleaned the same way as the text: [canonical => as written]. */
    private function lists(): array
    {
        if ($this->lists !== null) {
            return $this->lists;
        }

        $lists = ['tokens' => [], 'phrases' => [], 'stems' => [], 'combos' => []];
        foreach (['tokens', 'phrases', 'stems'] as $kind) {
            $entries = array_merge($this->config[$kind] ?? [], $this->config['family_' . $kind] ?? []);
            foreach ($entries as $entry) {
                foreach ([null, self::ARABIZI] as $digits) {
                    [$words, $spaced, $compact] = $this->shape($entry, $digits);
                    $key = match ($kind) {
                        'tokens' => $words[0] ?? '',
                        'phrases' => trim($spaced),
                        'stems' => $compact,
                    };
                    if ($key !== '') {
                        $lists[$kind][$key] ??= $entry;
                    }
                }
            }
        }

        foreach ($this->config['combos'] ?? [] as $rule) {
            $combo = ['window' => (int) ($rule['window'] ?? 6), 'family' => [], 'familyPhrases' => [], 'with' => [], 'withPhrases' => []];
            foreach ([null, self::ARABIZI] as $digits) {
                foreach (['family' => 'familyPhrases', 'with' => 'withPhrases'] as $key => $phraseKey) {
                    $entries = $rule[$key] ?? [];
                    if ($key === 'family') {
                        $entries = array_merge($entries, $rule['family_phrases'] ?? []);
                    }
                    foreach ($entries as $entry) {
                        $w = $this->shape($entry, $digits)[0];
                        if (count($w) === 1) {
                            $combo[$key][$w[0]] = true;
                        } elseif ($w) {
                            $combo[$phraseKey][implode(' ', $w)] = $w;
                        }
                    }
                }
            }
            $lists['combos'][] = $combo;
        }

        return $this->lists = $lists;
    }

    /**
     * A combination rule fires when a "family" word and a "with" word sit within the rule's window.
     * Returns the two words, e.g. "مرتك … كنكفتو", or null.
     */
    private function comboHit(array $combo, array $words): ?string
    {
        $familyAt = [];
        $withAt = [];
        foreach ($words as $i => $word) {
            foreach ($this->arabicVariants($word) as $variant) {
                if (isset($combo['family'][$variant])) {
                    $familyAt[$i] = $word;
                }
            }
            foreach (array_keys($combo['with']) as $stem) {
                if (mb_strlen($stem) >= 3 ? str_contains($word, $stem) : $word === $stem) {
                    $withAt[$i] = $word;
                }
            }
        }
        foreach ($combo['familyPhrases'] as $phrase => $parts) {
            foreach ($this->phrasePositions($words, $parts) as $i) {
                $familyAt[$i] = $phrase;
            }
        }
        foreach ($combo['withPhrases'] as $phrase => $parts) {
            foreach ($this->phrasePositions($words, $parts) as $i) {
                $withAt[$i] = $phrase;
            }
        }

        foreach ($familyAt as $i => $family) {
            foreach ($withAt as $j => $with) {
                if ($i !== $j && abs($i - $j) <= $combo['window']) {
                    return $i < $j ? $family . ' … ' . $with : $with . ' … ' . $family;
                }
            }
        }

        return null;
    }

    /** @return list<int> */
    private function phrasePositions(array $words, array $parts): array
    {
        $at = [];
        $n = count($parts);
        for ($i = 0; $i + $n <= count($words); $i++) {
            if (array_slice($words, $i, $n) === $parts) {
                $at[] = $i;
            }
        }

        return $at;
    }

    /** Arabic words often carry a prefix: و ف ب ل ال يا. Try the word with and without it. */
    private function arabicVariants(string $word): array
    {
        $variants = [$word];
        foreach (['وال', 'بال', 'فال', 'يا', 'ال', 'و', 'ف', 'ب', 'ل'] as $prefix) {
            if (str_starts_with($word, $prefix) && mb_strlen($word) - mb_strlen($prefix) >= 2) {
                $variants[] = mb_substr($word, mb_strlen($prefix));
            }
        }

        return $variants;
    }
}
