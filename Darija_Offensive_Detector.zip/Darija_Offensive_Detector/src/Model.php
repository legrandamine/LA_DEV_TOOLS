<?php

namespace DarijaOffensiveDetector;

/**
 * The small trained model: logistic regression over words, word pairs and letter fragments, built
 * from the same cleaned text as the word list. Loads model.json (about 1.3 MB) in a few milliseconds.
 */
class Model
{
    private ?array $data = null;

    public function __construct(private Engine $filter, private string $path)
    {
    }

    public function threshold(): float
    {
        return (float) ($this->load()['threshold'] ?? 0.99);
    }

    /**
     * Probability (0-1) that the text is offensive, and the words that pushed it up most.
     *
     * @return array{score: float, words: list<string>}
     */
    public function score(string $text): array
    {
        $data = $this->load();
        if ($data === null || trim($text) === '') {
            return ['score' => 0.0, 'words' => []];
        }

        $weights = $data['weights'];
        $z = (float) $data['bias'];
        $contributions = [];
        foreach (self::features($this->filter, $text) as $feature => $word) {
            if (isset($weights[$feature])) {
                $z += $weights[$feature];
                if ($weights[$feature] > 0) {
                    $contributions[$word] = ($contributions[$word] ?? 0) + $weights[$feature];
                }
            }
        }
        arsort($contributions);

        return ['score' => 1 / (1 + exp(-$z)), 'words' => array_slice(array_keys($contributions), 0, 3)];
    }

    /**
     * Features of a text: [feature => the word it came from]. Read as typed and as Arabizi.
     * Used for training and scoring; both must stay identical.
     *
     * @return array<string, string>
     */
    public static function features(Engine $filter, string $text): array
    {
        $features = [];
        foreach ([null, Engine::ARABIZI] as $digits) {
            $words = $filter->shape($text, $digits)[0];
            foreach ($words as $i => $word) {
                $features['w:' . $word] ??= $word;
                if (isset($words[$i + 1])) {
                    $features['b:' . $word . ' ' . $words[$i + 1]] ??= $word . ' ' . $words[$i + 1];
                }
                $padded = '<' . $word . '>';
                $length = mb_strlen($padded);
                for ($n = 3; $n <= 5; $n++) {
                    for ($k = 0; $k + $n <= $length; $k++) {
                        $features['c:' . mb_substr($padded, $k, $n)] ??= $word;
                    }
                }
            }
        }

        return $features;
    }

    private function load(): ?array
    {
        if ($this->data !== null) {
            return $this->data;
        }
        $json = json_decode((string) @file_get_contents($this->path), true);

        return $this->data = is_array($json) && isset($json['weights'], $json['bias']) ? $json : null;
    }
}
