# Darija Offensive Detector

Detects offensive words in **Moroccan Darija**, in Arabic script and in Arabizi (`9a7ba`, `l7mar`),
plus Arabic, French and English. Give it a text and it returns `true` if it contains a bad word,
`false` if not.

It runs on your own server: no API key, no account, no cost, no text sent anywhere. Plain PHP 8.1+,
and an HTTP API for sites written in anything else.

كاشف الكلام الخاسر بالدارجة المغربية، بالحروف العربية وبالعربيزي. مجاني، يخدم على السيرفر ديالك بلا API خارجي.

```php
use DarijaOffensiveDetector\Detector;

Detector::detect('salam khoya, bghit nkommandi');   // false
Detector::detect('wld l9a7ba');                      // true
Detector::detect('z.e.b.i');                         // true  (disguised spellings are caught)
```

## Install

With Composer, from GitHub (replace `YOUR-GITHUB-USERNAME`):

```bash
composer config repositories.darija vcs https://github.com/YOUR-GITHUB-USERNAME/Darija_Offensive_Detector
composer require legrandamine/darija-offensive-detector:dev-main
```

Without Composer, download the folder and:

```php
require 'Darija_Offensive_Detector/autoload.php';
```

Needs the `mbstring` extension. `intl` is recommended (better handling of accents and full-width letters).

## Use it in PHP

```php
use DarijaOffensiveDetector\Detector;

// One line, default settings
if (Detector::detect($_POST['comment'] ?? '')) {
    // refuse the comment
}

// With options
$detector = new Detector([
    'extra_words' => ['a word only your site blocks', 'another one'],
]);

$detector->isOffensive($text);    // true / false
$detector->findWords($text);      // ['qahba']: what was found, to show in a warning
$detector->checkFields([          // several form fields at once; returns only the offensive ones
    'name' => $name,
    'address' => $address,
]);                               // ['name' => ['zebi']], or [] when everything is clean
```

### Options

| Option | Default | What it does |
|---|---|---|
| `extra_words` | `[]` | More words or phrases to block. Write the plain spelling; disguised versions are caught too. |
| `allow_words` | `[]` | Built-in words to stop blocking, for example a family or place name your users really have. |
| `family_words` | `true` | Blocks "your / our" + wife, mother, sister or daughter on their own (`مرتك`, `mratek`, `ta mère`). Right for names, addresses and usernames. Set to `false` for chat or comments, where "كيداير مرتك؟" is innocent. The insulting combinations are still caught. |
| `use_model` | `true` | Uses the trained model for insults that contain no listed word. |
| `threshold` | `0.99` | How sure the model must be (0 to 1). Lower catches more but blocks more real names. Keep it at 0.97 or higher for name and address fields. |
| `words_file` | bundled | Path to your own copy of `config/words.php`. |

Create the `Detector` once and reuse it: the model loads in about 5 ms, then each check takes a
fraction of a millisecond.

### Laravel

```php
// app/Rules/NotOffensive.php
use Closure;
use DarijaOffensiveDetector\Detector;
use Illuminate\Contracts\Validation\ValidationRule;

class NotOffensive implements ValidationRule
{
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (Detector::detect((string) $value)) {
            $fail('This text contains words that are not allowed.');
        }
    }
}

// In a controller or form request
$request->validate(['name' => ['required', new NotOffensive]]);
```

## Use it from any language (HTTP API)

Start the server:

```bash
php -S 0.0.0.0:8080 server/index.php
```

or with Docker:

```bash
docker build -t darija-detector . && docker run -p 8080:8080 darija-detector
```

| Request | Response |
|---|---|
| `POST /detect` `{"text": "wld l9a7ba"}` | `{"offensive": true}` |
| `POST /detect` `{"text": "...", "details": true}` | `{"offensive": true, "words": ["qahba"]}` |
| `POST /detect` `{"fields": {"name": "...", "address": "..."}}` | `{"offensive": true, "fields": {"name": ["zebi"]}}` |
| `GET /detect?text=...` | `{"offensive": false}` |
| `GET /health` | `{"ok": true}` |

JavaScript:

```js
const res = await fetch('http://localhost:8080/detect', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ text: comment }),
});
const { offensive } = await res.json();
```

Python:

```python
import requests
offensive = requests.post("http://localhost:8080/detect", json={"text": comment}).json()["offensive"]
```

Server settings (environment variables):

| Variable | Default | What it does |
|---|---|---|
| `DOD_ALLOWED_ORIGINS` | `*` | Sites allowed to call it from a browser, comma separated. Set it in production. |
| `DOD_MAX_LENGTH` | `5000` | Longest text accepted, in characters. |
| `DOD_FAMILY_WORDS` | `1` | `0` turns off the "your wife / your mother" words (see `family_words`). |
| `DOD_EXTRA_WORDS` | | More words to block, comma separated. |

Check text on your server, not only in the browser: anything checked only in the browser can be skipped.

## How it decides

1. **Word list** (`config/words.php`): insults in Darija, Arabic, French, English and a few other
   languages. Short words must be a whole word, so `زب` does not block `زبون` and `nik` does not block
   `Nikolas`.
2. **Combination rules**: ordinary words that insult together, like "your wife" near sexual slang
   (`ستر مرتك راه كنكفتو عليها`).
3. **Trained model**: a small logistic-regression model (1.3 MB) for insults with no listed word. It
   only flags text it is at least 99% sure about, and only text that looks like Darija (Arabic letters,
   Arabizi digits, or common Darija words): it learned from Darija comments and is not reliable on
   plain English or French, which the word list covers.

Before comparing, every text is cleaned the same way, so these are all caught:

| Trick | Example |
|---|---|
| Arabizi digits | `9a7ba`, `l7mar`, `t9wd` |
| Leetspeak | `sh1t`, `f4ck` |
| Split letters | `z.e.b.i`, `z e b i`, `ق ح ب ة` |
| Masking | `f*ck`, `z_e_b_i` |
| Stretched letters | `zebiiiii`, `قحححبة` |
| Arabic letter forms, diacritics, tatweel | `أ/إ/آ`, `ة/ه`, `قـــحـــبة` |
| Look-alike letters from other alphabets | `ѕаlоре` (Cyrillic) |
| Invisible characters | zero-width spaces |

## Accuracy and limits

Measured on 20% of the training dataset that the model never saw: about **2 in 3 offensive comments
are caught**, and about 3% of normal comments are wrongly flagged. On real Moroccan names and addresses
(`دوار القحاونة`, `Hamid Lahmar`, `عبد الله الكلبي`, `شارع القواد`) and on everyday English and French
messages, none are flagged by the included tests.

It recognises words and patterns, not meaning. A polite-sounding insult can pass, and a new slang word
passes until it is added. Use it to stop the obvious cases automatically, and keep a way for people to
report what it misses.

## Make it better

- **Add words** in `config/words.php` (or `extra_words`). Write the plain spelling only.
  - `tokens`: single words, matched as whole words
  - `phrases`: several words in a row
  - `stems`: long, unmistakable words, matched even inside other words
  - `combos`: two groups of words that insult only together
- **Retrain the model** with your own labelled CSV (`text,label`, 1 = offensive, 0 = not). Takes about
  15 seconds for 20,000 rows and prints the accuracy before saving:
  ```bash
  php bin/train.php my-data.csv --precision=0.95
  ```
- **Run the tests** after any change:
  ```bash
  php tests/run.php
  ```

Pull requests with new words are welcome. Please add a test line for each word, and a normal name or
address that must still pass if the word could hide inside one.

## Credits

The model was trained on the *Moroccan Darija Offensive Language Detection Dataset* (20,402 labelled
comments). The dataset is not included in this repository.

## License

MIT. See [LICENSE](LICENSE).
