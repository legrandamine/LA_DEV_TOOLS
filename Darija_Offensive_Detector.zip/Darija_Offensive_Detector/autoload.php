<?php

// For projects without Composer: require 'Darija_Offensive_Detector/autoload.php';
spl_autoload_register(function (string $class): void {
    $prefix = 'DarijaOffensiveDetector\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/src/' . substr($class, strlen($prefix)) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});
