<?php

/*
 * Self-test, no dependencies:  php tests/run.php   (or: composer test)
 * Clean texts must return false, offensive ones true, including disguised spellings.
 */

require dirname(__DIR__) . '/autoload.php';

use DarijaOffensiveDetector\Detector;

$failures = 0;
$count = 0;
function expect(bool $actual, bool $expected, string $label): void
{
    global $failures, $count;
    $count++;
    if ($actual !== $expected) {
        $failures++;
        echo 'FAIL  ' . ($expected ? 'should be offensive: ' : 'should be clean:     ') . $label . "\n";
    }
}

$clean = [
    // Names and addresses
    'محمد أمين عبد اللاوي', 'Mohamed Amine Abdellaoui', 'زبون وفي، حي السلام زنقة 12 الدار البيضاء', 'Derb Sultan, rue 45, Casablanca',
    'Hay Nahda 2, Rabat', 'Nikolas Martin', 'Résidence Al Andalous, Appt 3', 'Zakaria Benkirane', 'كسكس بلدي', 'شارع الزبير بن العوام',
    'Saad Zebdi', 'Imm 7 Appt 3 Bloc B', 'Lot 9 N° 5, Hay Riad', 'شارع القواد', 'Jean-Pierre Lopez', 'حي الرحمة، عند دار ختي فاطمة',
    'عند ختي، دار يماي', 'Livrer chez ma mère, Hay Riad', 'Imane Mok', 'مصطفى الكبير، شارع محمد الخامس', 'ترامواي محطة الحسن الثاني',
    'عبد الله الكلبي', 'Hamid Lahmar', 'دوار القحاونة', 'Hôtel Atlas, Marrakech', 'قرب الاستراحة، طريق مكناس', 'World Trade Center Casablanca',
    // Everyday messages
    'hello world', 'I would like to order two bottles of honey', 'new world order', 'The quick brown fox jumps over the lazy dog',
    'Bonjour, je voudrais commander', 'Livraison rapide et produit de qualité', 'salam khoya kidayr', 'bghit nkommandi wa7d l3sel',
    'fin wsl lcolis dyali', 'merci bzaf 3la lkhdma', 'السلام عليكم بغيت نطلب', 'شكرا بزاف على الخدمة', 'العسل زوين بزاف الله يبارك',
    '', '   ',
];
$offensive = [
    'ستر مرتك راه كنكفتو عليها', 'str mratek rah kankfto 3liha', 'نتا غير حمار و ولد الحرام', 'ya l7mar sir t9wd', 'wld l9a7ba',
    'z.e.b.i', 'q7ba', 'ق ح ب ة', 'f*ck', 'ѕаlоре', 'nique ta mère', 'mratek skhona', 'ya l7mar', 'يا الحمار', 'nta kelb', 'الله يلعن بوك', 'nta wa7d l9lil l7ya',
    'مرتك', 'مراتنا', 'your wife', 'bnadm jato fchkla warah vrai azbi', 'baise moi',
];

foreach ($clean as $text) {
    expect(Detector::detect($text), false, $text);
}
foreach ($offensive as $text) {
    expect(Detector::detect($text), true, $text);
}
expect(Detector::detect(null), false, 'null');

// Options
$chat = new Detector(['family_words' => false]);
expect($chat->isOffensive('كيداير مرتك؟'), false, 'family_words off: كيداير مرتك؟');
expect($chat->isOffensive('ستر مرتك راه كنكفتو عليها'), true, 'family_words off still catches the combination');

$custom = new Detector(['extra_words' => ['banana split', 'tomatoz']]);
expect($custom->isOffensive('I love b.a.n.a.n.a split'), true, 'extra phrase, disguised');
expect($custom->isOffensive('t0matoz'), true, 'extra word, leetspeak');
expect(Detector::detect('tomatoz'), false, 'extra words do not leak into the default detector');

$allow = new Detector(['allow_words' => ['merde']]);
expect($allow->isOffensive('merde'), false, 'allow_words');
expect(Detector::detect('merde'), true, 'allow_words do not leak into the default detector');

$noModel = new Detector(['use_model' => false]);
expect($noModel->isOffensive('wld l9a7ba'), true, 'word list works without the model');

$fields = (new Detector())->checkFields(['name' => 'zebi', 'address' => 'Hay Riad, Rabat']);
expect(array_keys($fields) === ['name'], true, 'checkFields returns only the offensive field');

echo $failures === 0 ? "All $count checks passed.\n" : "$failures of $count checks failed.\n";
exit($failures === 0 ? 0 : 1);
