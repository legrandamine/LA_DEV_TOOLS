<?php

/*
 * Small HTTP API, for sites not written in PHP (Node, Python, Django, React…).
 *
 *   php -S 0.0.0.0:8080 server/index.php        (or: docker build -t darija-detector . && docker run -p 8080:8080 darija-detector)
 *
 *   POST /detect   {"text": "..."}               -> {"offensive": true}
 *   POST /detect   {"text": "...", "details": true} -> {"offensive": true, "words": ["qahba"]}
 *   POST /detect   {"fields": {"name": "...", "address": "..."}} -> {"offensive": true, "fields": {"name": ["zebi"]}}
 *   GET  /detect?text=...                         -> {"offensive": false}
 *   GET  /health                                  -> {"ok": true}
 *
 * Settings come from environment variables:
 *   DOD_ALLOWED_ORIGINS  CORS origins, comma separated (default "*")
 *   DOD_MAX_LENGTH       longest text accepted, in characters (default 5000)
 *   DOD_FAMILY_WORDS     "0" to stop flagging "your wife / your mother…" on their own
 *   DOD_EXTRA_WORDS      more words to block, comma separated
 */

require dirname(__DIR__) . '/autoload.php';

use DarijaOffensiveDetector\Detector;

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
$origins = array_map('trim', explode(',', getenv('DOD_ALLOWED_ORIGINS') ?: '*'));
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array('*', $origins, true)) {
    header('Access-Control-Allow-Origin: *');
} elseif ($origin !== '' && in_array($origin, $origins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

function respond(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($path === '/health') {
    respond(200, ['ok' => true]);
}
if ($path !== '/detect' && $path !== '/') {
    respond(404, ['error' => 'Not found. Use POST /detect with {"text": "..."}.']);
}

if ($method === 'POST') {
    $raw = (string) file_get_contents('php://input', false, null, 0, 1_000_000);
    $input = str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') ? json_decode($raw, true) : $_POST;
    if (! is_array($input)) {
        respond(400, ['error' => 'Send JSON like {"text": "..."}.']);
    }
} elseif ($method === 'GET') {
    $input = $_GET;
} else {
    respond(405, ['error' => 'Use GET or POST.']);
}

$max = (int) (getenv('DOD_MAX_LENGTH') ?: 5000);
$fields = isset($input['fields']) && is_array($input['fields']) ? $input['fields'] : null;
$texts = $fields ?? ['text' => $input['text'] ?? null];
foreach ($texts as $name => $value) {
    if ($value !== null && ! is_string($value)) {
        respond(400, ['error' => "\"$name\" must be a string."]);
    }
    if (mb_strlen((string) $value, 'UTF-8') > $max) {
        respond(413, ['error' => "\"$name\" is longer than $max characters."]);
    }
}
if ($fields === null && ($input['text'] ?? null) === null) {
    respond(400, ['error' => 'Missing "text".']);
}

$detector = new Detector([
    'family_words' => getenv('DOD_FAMILY_WORDS') !== '0',
    'extra_words' => array_filter(array_map('trim', explode(',', (string) getenv('DOD_EXTRA_WORDS')))),
]);

if ($fields !== null) {
    $found = $detector->checkFields($fields);
    respond(200, ['offensive' => $found !== [], 'fields' => (object) $found]);
}

$words = $detector->findWords($input['text']);
$details = filter_var($input['details'] ?? false, FILTER_VALIDATE_BOOL);
respond(200, $details ? ['offensive' => $words !== [], 'words' => $words] : ['offensive' => $words !== []]);
