<?php

// php examples/basic.php

require dirname(__DIR__) . '/autoload.php';   // or: require 'vendor/autoload.php';

use DarijaOffensiveDetector\Detector;

var_dump(Detector::detect('salam khoya, bghit nkommandi'));   // bool(false)
var_dump(Detector::detect('wld l9a7ba'));                      // bool(true)

$detector = new Detector(['extra_words' => ['some word only your site blocks']]);

$name = 'z.e.b.i';
if ($detector->isOffensive($name)) {
    echo 'Please remove this word: ' . implode(', ', $detector->findWords($name)) . "\n";
}
