<?php

/*
|--------------------------------------------------------------------------
| Darija Offensive Detector: word lists
|--------------------------------------------------------------------------
| Every entry and every customer text go through the same clean-up before comparing, so you only
| list the plain spelling. Already handled automatically:
|   - case, accents (é -> e), Arabic letter forms (أ/إ/آ -> ا, ة -> ه, ى -> ي), diacritics, tatweel (ـ)
|   - stretched or doubled letters: "zebiiii", "zebbi", "قحححبة"
|   - letters split by spaces, dots, dashes, stars or emoji: "z.e.b.i", "z e b i", "f*ck", "ق ح ب ة"
|   - leetspeak: 0->o 1->i 3->e 4->a 5->s 7->t 8->b @->a $->s
|   - Arabizi digits read as letters: 3->a 7->h 9->q 2->a 5->kh 8->gh ("9a7ba" = "qahba")
|   - look-alike letters from other alphabets (Cyrillic "а", Greek "ο") and full-width letters
|   - invisible characters (zero-width spaces)
|
| - tokens:  must equal a whole word. For short words that hide inside normal words
|            ("زب" in "زبون" customer, "nik" in "Nikolas").
| - phrases: several words in a row.
| - stems:   matched anywhere, even glued to other words. Only long, unmistakable words.
| - family_tokens / family_phrases: "your / our" + wife, mother, sister, daughter. Flagged on their own
|            by default; turn off with new Detector(['family_words' => false]) for chat or comments.
| - combos:  two groups of words that insult only together.
*/

return [
    'tokens' => [
        // ---------- Arabic & Darija (Arabic script) ----------
        'زب', 'زبي', 'زبك', 'زبه', 'زبيك', 'زبور', 'زبوري', 'عير', 'عيري', 'عيرك',
        'كس', 'كسك', 'كسها', 'كسمك', 'كسختك', 'طيز', 'طيزك', 'طيزي', 'زك', 'الزك', 'زكمك', 'ترمه', 'ترمتك',
        'نيك', 'انيك', 'نيكك', 'نيكمك', 'تنيك', 'نيكني', 'منيكه', 'نحويك', 'حواك', 
        'خرا', 'خره', 'خرتك', 'مقواد', 'ديوث', 'لوطي', 'خول', 'عرص', 'معرص',
        'زامل', 'زوامل', 'طبون', 'الطبون', 'طبونمك', 'قلاوي', 'بزول', 'بزاز', 'سكس', 'بورن',
        // ---------- Darija / Arabizi (Latin script; digit spellings are matched automatically) ----------
        'zeb', 'zbi', 'zebi', 'zab', 'zbek', 'zebk', 'nik', 'nikmok', 'nikmk', 'nkmk', 'nikomk', 'nekmok', 'n7wik', 'nhwik',
        'n7wi', 'nhwi', 't7wa', 'thwa', 'zok', 'zek', 'zk', 'zokmok', 'khra', 'khara', 'khera', 'zamel', 'zaml', 'zamal', 'zamla',
        'zwamel', 'azbi', 'tabon', 'tbon', 'tboun', 'tboune', 'tabbon', 'qlawi', 'klawi', 'qwad', 'qawad', 'kawad', 'tqawd', 'tqwd',
        'mqawed', 'mqwd', 'terma', 'tarma', 'bzoul', 'bzazl', 'tfou', 'tfo', 'qahba', 'kahba', 'gahba', 'qhba', 'qahab',
        // ---------- French ----------
        'pute', 'putain', 'putin', 'tepu', 'salope', 'salop', 'salaud', 'connard', 'connasse', 'encule', 'enculer',
        'nique', 'niquer', 'ntm', 'ntr', 'fdp', 'batard', 'merde', 'couille', 'couilles', 'chienne', 'pd', 'pede', 'tapette',
        'pouffiasse', 'poufiasse', 'petasse', 'enfoire', 'branleur', 'branler', 'suce', 'sucer', 'zob', 'teub', 'chibre',
        'gouine', 'tarlouze', 'negre', 'bougnoule', 'youpin',
        // ---------- English ----------
        'fuck', 'fucker', 'fucking', 'fuk', 'fck', 'phuck', 'motherfucker', 'shit', 'bitch', 'biatch', 'btch', 'cunt',
        'pussy', 'asshole', 'bastard', 'whore', 'slut', 'nigger', 'nigga', 'faggot', 'fag', 'wtf', 'stfu', 'cock', 'twat',
        'wanker', 'bollocks', 'prick', 'retard', 'dumbass', 'jackass', 'dipshit', 'porn',
        // ---------- Spanish, Italian, German, Turkish ----------
        'puta', 'puto', 'mierda', 'cabron', 'pendejo', 'cono', 'joder', 'cazzo', 'stronzo', 'vaffanculo',
        'scheisse', 'arschloch', 'hurensohn', 'orospu', 'siktir',
    ],

    'phrases' => [
        // Arabic & Darija
        'كس امك', 'كس اختك', 'كس ام', 'ابن الكلب', 'ابن القحبه', 'ولد القحبه', 'بنت القحبه', 'ولد الحرام', 'ابن الحرام',
        'بنت الحرام', 'ابن الزنا', 'ابن المتناكه', 'يلعن دينك', 'يلعن ربك', 'يلعن ابوك', 'يلعن امك', 'نيك امك', 'مص زبي',
        'تفو عليك', 'سير تقود', 'الله ينعل', 'ينعل دين', 'يلعن بوك', 'يلعن بوها', 'نعل بوك', 'الله يلعن', 'قليل الحيا', 'قليلة الحيا',
        'قليل الترابي', 'قليلة الترابي', 'يا الحمار', 'يا حمار', 'نتا حمار', 'نتي حمارة', 'يا الكلب', 'يا كلب', 'نتا كلب', 'ولد الزنقة', 'بنت الزنقة',
        // Darija / Arabizi
        'wld l9a7ba', 'wld lqahba', 'wld l7ram', 'bent l9a7ba', 'nik mok', 'nik mmok', 'nik yamak', 'tfou 3lik', 'sir t9awd',
        'sir tqawd', 'lah yn3al', 'yn3al din', 'n3al din', 'tbon mok', 'y3l bok', 'yl3an bok', 'n3al bok', 'qlil lhya', 'l9lil l7ya',
        'qlila lhya', 'qlil trabi', 'ya lhmar', 'ya hmar', 'nta hmar', 'nti hmara', 'ya lhmara', 'ya lkelb', 'ya lkalb', 'nta kelb', 'wld zn9a', 'bent zn9a',
        // French
        'fils de pute', 'fils de chien', 'nique ta mere', 'nique ta race', 'ta mere la pute', 'va te faire', 'sale pute',
        'trou du cul', 'baise moi', 'ta gueule', 'ferme ta gueule', 'sale arabe', 'sale noir',
        // English
        'son of a bitch', 'fuck you', 'fuck off', 'go to hell', 'piece of shit', 'suck my', 'mother fucker',
    ],

    /*
    | "Your / our" + female family. In a name, an address or a username these are only ever used to
    | provoke; "my" forms (مرتي, ختي, ma mère) are allowed. In free messages they can be innocent
    | ("كيداير مرتك؟"), so they can be turned off; the combination rules still catch the insulting uses.
    */
    'family_tokens' => [
        'مرتك', 'مراتك', 'مرتكم', 'مراتكم', 'زوجتك', 'زوجتكم', 'مراتنا', 'مرتنا', 'زوجاتنا', 'عيالاتنا', 'عيالاتكم', 'عيالاتك',
        'ختك', 'اختك', 'ختكم', 'اختكم', 'خواتاتك', 'خواتاتكم', 'خواتك', 'خواتكم', 'خواتاتنا', 'خواتنا',
        'يماك', 'يماكم', 'امك', 'امكم', 'مك', 'مكم', 'ماماك', 'مامتك', 'يماتكم', 'امهاتكم',
        'بنتك', 'بنتكم', 'بناتك', 'بناتكم', 'بناتنا', 'حبيبتك', 'صاحبتك',
        'mratek', 'mratk', 'mrtk', 'mratkom', 'mratna', 'mrtna', 'khtk', 'khtek', 'okhtek', 'khtak', 'khtkom', 'khwatatek', 'khwatatkom',
        'khwatatna', 'yemmak', 'yemak', 'yemmakom', 'mmkom', 'mamak', 'bentek', 'bntk', 'bnatek', 'bnatkom', 'bnatna',
    ],

    'family_phrases' => [
        'ta femme', 'ta mere', 'ta soeur', 'ta fille', 'ta copine', 'vos femmes', 'nos femmes', 'your wife', 'your mother', 'your mom',
        'your sister', 'your daughter',
    ],

    'stems' => [
        // Arabic & Darija
        'قحبه', 'قحاب', 'قحيبه', 'شرموط', 'منيوك', 'متناك', 'معرص', 'عاهره', 'عاهر', 'تقواد', 'تقاود', 'كسمك', 'كسختك',
        'زبوبه', 'نيكمك', 'طبونمك', 'زكمك', 'داعر',
        // Darija / Arabizi (written plain; "9a7ba", "q7ba", "ka7ba" are covered by digit reading)
        'qahba', 'qahab', 'kahba', 'gahba', 'tqawed', 'tqawd', 'nhwik', 'hwayatek', 'zamla', 'zwamel', 'nikmok', 'zokmok',
        // French / English / others
        'salope', 'connard', 'connasse', 'encule', 'pouffiasse', 'poufiasse', 'petasse', 'motherfuck', 'fuckyou', 'fuckoff',
        'bitchass', 'asshole', 'hurensohn', 'vaffanculo', 'filsdepute', 'niquetamere', 'tamerelapute',
    ],

    /*
    | Combination rules: two groups of words that are harmless alone but insulting together, when they
    | appear within "window" words of each other. Free and local, no AI. Example caught:
    | "ستر مرتك راه كنكفتو عليها" = "your wife" + sexual slang.
    | - family: matched as whole words (Arabic prefixes like و/ف/ب/ل/ال/يا are allowed).
    | - with:   matched anywhere inside a word ("كفت" catches "كنكفتو", "تكفت", "كفتناها").
    */
    'combos' => [
        [
            'label' => 'insult to family honour',
            'window' => 6,
            'family' => [
                // Darija / Arabic: your wife, mother, sister, daughter, women of your family
                'مرتك', 'مراتك', 'مرات', 'مرتو', 'مراتو', 'زوجتك', 'زوجتو', 'ختك', 'اختك', 'ختو', 'اختو', 'خواتاتك', 'خواتك',
                'يماك', 'امك', 'مك', 'ماماك', 'مامتك', 'بنتك', 'بناتك', 'عيالاتك', 'عيالك', 'عيالتك', 'حبيبتك', 'صاحبتك',
                // plural "your" (-كم)
                'مراتكم', 'زوجاتكم', 'ختكم', 'خواتاتكم', 'خواتكم', 'يماتكم', 'امكم', 'مكم', 'بناتكم', 'عيالاتكم', 'عيالكم',
                // Arabizi
                'mratek', 'mratk', 'mrtk', 'mrat', 'mratou', 'khtk', 'khtek', 'okhtek', 'khtak', 'yemmak', 'yemak', 'mmok', 'mok',
                'mamak', 'bentek', 'bntk', 'bnatek', '3yalatek', 'sa7btek', 'sahbtek', 'mratkom', 'khtkom', 'khwatatkom', 'yematkom', 'mmkom', 'bnatkom', '3yalatkom',
            ],
            'family_phrases' => ['ta femme', 'ta mere', 'ta soeur', 'ta fille', 'ta copine', 'your wife', 'your mother', 'your mom', 'your sister', 'your daughter', 'your girlfriend'],
            'with' => [
                // shaming: "cover / control your wife"
                'ستر', 'سترها',
                // sexual slang (Darija / Arabic)
                'كفت', 'نيك', 'نيكو', 'حويت', 'نحوي', 'كنحوي', 'تحوا', 'حواها', 'كنحويو', 'زبي', 'طبون', 'ترمه', 'ترمتها', 'مصها', 'كنمص', 'لحس', 'قحب', 'شرموط',
                'عاهر', 'نركبو', 'كنركبو', 'نعس معا', 'بات معا', 'سخونه',
                // Arabizi
                'kfet', 'kfto', 'kftou', 'nik', 'n7wi', 'nhwi', '7wit', 'hwit', '7wa', 'zeb', 'zbi', 'tbon', 'terma', 'qahb', 'kahb',
                'n3es m3a', 'skhona', 'sokhna',
                // French / English
                'baise', 'baiser', 'nique', 'suce', 'couche avec', 'salope', 'pute', 'fuck', 'bang', 'sleep with', 'slut', 'whore',
            ],
        ],
    ],
];
